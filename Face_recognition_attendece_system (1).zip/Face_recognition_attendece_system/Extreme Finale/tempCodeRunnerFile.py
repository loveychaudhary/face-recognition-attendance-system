def upload():
    f = open(f'Attendance/Attendance-{datetoday}.csv', 'r') 
    return f.read()

print(upload())